﻿using UnityEngine;
using System.Collections;

namespace LAO.Generic.Animation {

    /// <summary>
    /// Moves object across in a straight line like a bullet
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class Bullet : MonoBehaviour {

        public float speed;
        public Rigidbody rb;

        // Use this for initialization
        void Start() {
            if(speed <= 0) {
                speed = 200;
            }

            //attempt to find rigidbody
            if(rb == null) {
                rb = this.gameObject.GetComponent<Rigidbody>();
            }

           //to project forward and its current rotation
           //use tranform forward,right,left,up instead of vector.forward
           //vector forward is refering to world space, so it will always go to the same direction
           rb.AddForce(gameObject.transform.right * speed);

            Destroy(gameObject, 2f);
        }

        // Update is called once per frame
        void Update() {
           //rb.AddForce(new Vector3();
        }
    }
}