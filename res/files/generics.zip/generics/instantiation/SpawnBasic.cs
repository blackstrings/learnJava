﻿using UnityEngine;
using System.Collections;

namespace LAO.Generic.Instantiation {

    /// <summary>
    /// Spawns target prefabs to random location
    /// Basic use is put the script on a plane gameObject
    /// Make sure to choose target_pf and spawnArea_go
    /// The spawnArea controls where and what areas random spawns can occur in
    /// </summary>
    public class SpawnBasic : MonoBehaviour {

        public GameObject target_pf;

        // Use this for initialization
        void Start() {

            //action();
            StartCoroutine(timerSpawn());
        }

        float delay = 2f;
        IEnumerator timerSpawn() {
            float timerCounter = 0;

            //delay
            while(timerCounter <= delay) {
                
                timerCounter += Time.deltaTime;
                yield return null;
            }

            //when timer is up, call this
            action();

            //repeat
            StartCoroutine(timerSpawn());
        }

        public void action() {
            Renderer rend = gameObject.GetComponent<Renderer>();
            float x = rend.bounds.size.x;
            float y = rend.bounds.size.y;
            x = Random.Range(0, x);
            y = Random.Range(0, y);

            GameObject tmpGo = (GameObject)Instantiate(target_pf, this.gameObject.transform.position, Quaternion.identity);
            

            tmpGo.transform.Translate(x, 0, y);
        }

        // Update is called once per frame
        void Update() {

        }
    }
}