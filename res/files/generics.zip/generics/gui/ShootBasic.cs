﻿using UnityEngine;
using System.Collections;
using System;
using LAO.Generic.Animation;

namespace LAO.Generic.Gui {

    /// <summary>
    /// A very basic shoot button.
    /// Attach it to a parent go.
    ///  Pareent should have a child that has a empty bulletSpawnLocator_go for the bullet to spawn.
    /// Also map the bullet prefab.
    /// </summary>
    public class ShootBasic : MonoBehaviour {

        public GameObject bullet_pf;
        public GameObject bulletSpawnLocator_go;  //a location for the bullet to spawn on

        // Use this for initialization
        void Start() {
            if (!bullet_pf) {
                throw new Exception("bullet_go prefab not set");
            }

        }

        //gui or controlls should call this
        public void action() {
            GameObject tempBullet_pf = (GameObject)Instantiate(Resources.Load("prefabs/bullet_pf"));
            tempBullet_pf.AddComponent<Bullet>();
            tempBullet_pf.transform.position = bulletSpawnLocator_go.transform.position;
            tempBullet_pf.transform.rotation = bulletSpawnLocator_go.transform.rotation;


        }
    }
}