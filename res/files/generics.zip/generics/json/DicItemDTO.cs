﻿using UnityEngine;
using System.Collections;

namespace LAO.Generic {

    public class DicItemDTO : MonoBehaviour {
        public string nameOfItem { get; set; }
        public string type { get; set; }
        public int age { get; set; }

    }
}