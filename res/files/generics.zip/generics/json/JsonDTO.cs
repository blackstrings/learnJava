namespace LAO.Generic {

    [System.Serializable]
    public class JsonDTO {
        //	public string name = false;
        //	public bool isAvaiable = true;
        //	public int length = 10.0;
        //	public double width = 5.0;
    }
}